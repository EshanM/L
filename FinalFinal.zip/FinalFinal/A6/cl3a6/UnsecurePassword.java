public class UnsecurePassword
{
	public String Password;
	UnsecurePassword(String str)
	{
		Password = str;
	}
}
