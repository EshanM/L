import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;
public class Client{
	private static Socket socket;
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Input Data :: ");
		String data = sc.nextLine();
		BobKey obj = new BobKey();
		System.out.println("\n:: :: DSA Algorithm:: ::\n:: :: Key Generation:: ::");
		obj.generateKey();
		System.out.println("Public Key (p,q,g,y)");
		System.out.println("p :: "+obj.p);
		System.out.println("q :: "+obj.q);
		System.out.println("g :: "+obj.g);
		System.out.println("y :: "+obj.y);
		System.out.println("\n:: :: Signature Generation :: ::");
		System.out.println("Digital Signature m(r,s)");
		BigInteger r = obj.generateR();
		BigInteger s = obj.generateS(r, data.getBytes());
		System.out.println("r :: "+r);
		System.out.println("s :: "+s);
		try
		{
			String host = "localhost";
			int port = 25000;
			InetAddress address = InetAddress.getByName(host);
			socket = new Socket(address, port);
			//System.out.println("You’re now connected to the Server");
			/*this should only print once */
			//Send the message to the server
			OutputStream os = socket.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(os);
			BufferedWriter bw = new BufferedWriter(osw);
			String sendMessage = obj.p + "\n";
			bw.write(sendMessage);
			sendMessage = obj.q + "\n";
			bw.write(sendMessage);
			sendMessage = obj.g + "\n";
			bw.write(sendMessage);
			sendMessage = obj.y + "\n";
			bw.write(sendMessage);
			sendMessage = r + "\n";
			bw.write(sendMessage);
			sendMessage = s + "\n";
			bw.write(sendMessage);
			sendMessage = data + "\n";
			bw.write(sendMessage);
			bw.flush();
			System.out.println("Data sent to the server");
		}
		catch (IOException exception)
		{
			System.out.println("Server is still offline");
		/*This should only print once*/
		}
	}
}
