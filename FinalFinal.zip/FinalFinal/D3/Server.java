import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.math.BigInteger;
import java.net.ServerSocket;
import java.net.Socket;
public class Server{
	private static Socket socket;
		public static void main(String[] args)
		{
			try
			{
			Key obj = new Key();
				int port = 25000;
				ServerSocket serverSocket = new ServerSocket(port);
				//Server is running always. This is done using this while(true) loop
				//Reading the message from the client
				socket = serverSocket.accept();
				System.out.println("Client has connected!");
				InputStream is = socket.getInputStream();
				InputStreamReader isr = new InputStreamReader(is);
				BufferedReader br = new BufferedReader(isr);
				String p = br.readLine();
				String q = br.readLine();
				String g = br.readLine();
				String y = br.readLine();
				String r = br.readLine();
				String s = br.readLine();
				String data = br.readLine();
				System.out.println("Message received from client");
				System.out.println("p :: "+p);
				System.out.println("q :: "+q);
				System.out.println("g :: "+g);
				System.out.println("y :: "+y);
				System.out.println("r :: "+r);
				System.out.println("s :: "+s);
				System.out.println("data :: "+data);
				System.out.println("\n:: :: Signature Verification :: ::");
				obj.p = new BigInteger(p);
				obj.q = new BigInteger(q);
				obj.g = new BigInteger(g);
				obj.y = new BigInteger(y);
				BigInteger Bigr = new BigInteger(r);
				BigInteger Bigs = new BigInteger(s);
				if(obj.verify(data.getBytes(),Bigr, Bigs))
				{
					System.out.println("Algorithm Valid");
				}
				else
				{
					System.out.println("Algorithm Invalid");
				}
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
	}
}
